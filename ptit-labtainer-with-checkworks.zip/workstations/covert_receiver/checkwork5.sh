#!/bin/bash
if [ -f /tmp/received_data.txt ]; then
    echo "Check 5 PASSED: received_data.txt exists."
else
    echo "Check 5 FAILED: received_data.txt not found."
fi
