#!/bin/bash
if grep -q "secret" /tmp/received_data.txt; then
    echo "Check 3 PASSED: 'secret' received."
else
    echo "Check 3 FAILED: 'secret' not found in received_data.txt."
fi
