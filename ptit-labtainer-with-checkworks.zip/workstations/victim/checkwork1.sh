#!/bin/bash
if [ -f /etc/iptables.rules ]; then
    echo "Check 1 PASSED: iptables.rules exists."
else
    echo "Check 1 FAILED: iptables.rules does not exist."
fi
