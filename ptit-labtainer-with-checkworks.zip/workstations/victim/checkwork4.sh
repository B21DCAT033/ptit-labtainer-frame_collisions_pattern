#!/bin/bash
if [ -s /var/log/syslog ]; then
    echo "Check 4 PASSED: syslog is not empty."
else
    echo "Check 4 FAILED: syslog is empty or missing."
fi
