#!/bin/bash
if grep -q "secret" /tmp/sent_data.txt; then
    echo "Check 2 PASSED: 'secret' found in sent_data.txt."
else
    echo "Check 2 FAILED: 'secret' not found."
fi
